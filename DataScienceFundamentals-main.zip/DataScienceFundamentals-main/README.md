# DataScienceFundamentals
Learning Data Science step by step!!!

Step 1: Python fundamentals 

Step 2: Numpy

Step 3: Matplotlib

Step 4: Pandas
